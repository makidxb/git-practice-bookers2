# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '2e4566a78240b86b9b3b2dc5f42b558c976aefcc3752929d1fafaf47efdb3d70b5a0819113a8a230f65358be7136da756e8c8bc22abdd0327f0137c073a4fab0'