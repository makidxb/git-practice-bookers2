class HomesController < ApplicationController

  def top
  end

  def index
  end

end
